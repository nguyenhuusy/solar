export interface VoltageRepositoryInterface {
    getVoltage(limit: number): void;
}
