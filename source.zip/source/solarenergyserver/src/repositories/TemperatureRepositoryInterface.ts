export interface TemperatureRepositoryInterface {
    getTemperature(limit: number): void;
}
