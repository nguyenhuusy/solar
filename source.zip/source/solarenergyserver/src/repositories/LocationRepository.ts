import {LocationInterface, LocationModel} from '../models';
import {LocationRepositoryInterface} from './LocationRepositoryInterface';
import {LocationDataInterface} from '../utils/interfaces';

export class LocationRepository implements LocationRepositoryInterface {
    private _locationModel: LocationModel;

    constructor(locationModel: LocationModel) {
        this._locationModel = locationModel;
    }

    async createLocation(newLocation: LocationInterface): Promise<LocationInterface> {
        return await this._locationModel.create(newLocation);
    }

    async getLocations(): Promise<any[]> {
        return this._locationModel.find().exec();
    }

    async getLocationById(id: string): Promise<LocationInterface> {
        return await this._locationModel.findById(id).exec();
    }

    async updateLocation(id: string, updatedLocation: LocationInterface): Promise<LocationInterface> {
        return await this._locationModel.findByIdAndUpdate(id, updatedLocation).exec();
    }

    async getLocationByUuid(uuid: string): Promise<LocationInterface> {
        return await this._locationModel.findOne({uuid}).exec();
    }
}
