import {EntityRepository} from '../repositories';
import {Entity} from '../models';
import {EntityDataInterface} from '../utils/interfaces';
import {EmitEventSocket, EntityType, OnEventSocket} from '../utils/enum';

export class EntityController {
    private readonly _entityRepository = new EntityRepository(Entity);

    handleEvent(socket: any) {
        socket.on(OnEventSocket.RequestUpdateVoltage, async (data: EntityDataInterface) => {
            try {
                await this.saveEntity(data, EntityType.Voltage);
                socket.emit(EmitEventSocket.ResponseUpdateVoltage, EntityController.getResultFromSaveEntity({
                    type: EntityType.Voltage,
                    isSuccess: true,
                    uuid: data.uuid
                }));
            } catch (e) {
                console.error('-----Error when saving voltage: ', e);
                socket.emit(EmitEventSocket.ResponseUpdateVoltage, EntityController.getResultFromSaveEntity({
                    type: EntityType.Voltage,
                    isSuccess: false,
                    uuid: data.uuid
                }));
            }
        });

        socket.on(OnEventSocket.RequestUpdateTemperature, async (data: EntityDataInterface) => {
            try {
                await this.saveEntity(data, EntityType.Temperature);
                socket.emit(EmitEventSocket.ResponseUpdateTemperature, EntityController.getResultFromSaveEntity({
                    type: EntityType.Temperature,
                    isSuccess: true,
                    uuid: data.uuid
                }));
            } catch (e) {
                console.error('-----Error when saving temperature: ', e);
                socket.emit(EmitEventSocket.ResponseUpdateTemperature, EntityController.getResultFromSaveEntity({
                    type: EntityType.Temperature,
                    isSuccess: false,
                    uuid: data.uuid
                }));
            }
        });
    }

    private async saveEntity(data: EntityDataInterface, type: EntityType) {
        const newEntity = new Entity();
        newEntity.stationUuid = data.uuid;
        newEntity.createdBy = new Date().toLocaleString();
        newEntity.type = type;
        newEntity.value = +type === EntityType.Voltage ? data.voltage : data.temperature;
        return await this._entityRepository.createEntity(newEntity);
    }

    private static getResultFromSaveEntity(result: { type: EntityType, uuid: string, isSuccess: boolean }) {
        return {
            uuid: result.uuid,
            status: result.isSuccess ? 'Success' : 'Fail',
            updatedOn: Date.now(),
            type: +result.type === EntityType.Voltage ? 'Voltage' : 'Temperature',
        }
    }

    async getEntitiesByQuery(query: any) {
        return await this._entityRepository.getEntities(query);
    }
}
