import {MongoError} from "mongodb";
import {UserRepository} from '../repositories';
import {UserInterface, User} from '../models';
import {
    ErrorResponseInterface, SignInRequestInterface,
    SignInResponseInterface, SignUpRequestInterface,
    SignUpResponseInterface
} from '../utils/interfaces';
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import config from 'config';

export class AuthController {
    private static resolveErrorResponse(error: MongoError | null, message: string): ErrorResponseInterface {
        return {
            thrown: true,
            error,
            message
        };
    }

    private readonly _userRepository = new UserRepository(User);

    async registerUser(requestBody: SignUpRequestInterface): Promise<SignUpResponseInterface> {
        const existUser: UserInterface = await this._userRepository.getUserByEmailOrUsername(requestBody.email, requestBody.username);

        if (existUser instanceof MongoError) {
            throw AuthController.resolveErrorResponse(existUser, existUser.message);
        }

        if (existUser) {
            throw AuthController.resolveErrorResponse(null, 'Email or Username already existed.');
        }

        const newUser = new User();
        const salt = await bcrypt.genSalt(10);

        newUser.username = requestBody.username;
        newUser.email = requestBody.email;
        newUser.password = await bcrypt.hash(requestBody.password, salt);

        return await this._userRepository.createUser(newUser);
    }

    async login(loginParams: SignInRequestInterface): Promise<SignInResponseInterface> {
        const fetchedUser: UserInterface = await this._userRepository.getUserByEmailOrUsername(null, loginParams.username);
        const isMatched: boolean = await bcrypt.compareSync(loginParams.password, fetchedUser.password);

        if (fetchedUser instanceof MongoError) {
            throw AuthController.resolveErrorResponse(fetchedUser, fetchedUser.message);
        }

        if (!fetchedUser) {
            throw AuthController.resolveErrorResponse(null, 'Does not exist');
        }

        if (!isMatched) {
            throw AuthController.resolveErrorResponse(null, 'Password does not match');
        }

        const payload = {user: fetchedUser};
        const token: string = jwt.sign(payload, process.env.JWT_SECRET || config.get('auth.jwt_secret'), {expiresIn: 1800});

        if (!token) {
            throw AuthController.resolveErrorResponse(null, 'Error signing payload');
        }

        try {
            return {
                token: `JWT ${token}`
            };
        } catch (error) {
            throw AuthController.resolveErrorResponse(
                error instanceof MongoError ? error : null,
                error instanceof MongoError ? error.message : 'Unexpected Error');
        }
    }
}
