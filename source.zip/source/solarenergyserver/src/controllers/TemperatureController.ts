import {Temperature} from '../models';
import {OnEventSocket} from '../utils/enum';
import {EntityDataInterface} from '../utils/interfaces';
import {TemperatureRepository} from '../repositories/TemperatureRepository';

export class TemperatureController {
    private readonly _temperatureRepository = new TemperatureRepository(Temperature);

    async getTemperatures(uuid: string, limit: number) {
        return await this._temperatureRepository.getTemperature(+limit);
    }

    handleEvent(socket: any) {
        socket.on(OnEventSocket.RequestUpdateTemperature, async (data: EntityDataInterface) => {
            const temperatures = await this._temperatureRepository.getTemperature(10);
            socket.emit('updateTemperature', temperatures);
        });
    }

    // updateVoltage() {
    //     const newData = [];
    //     for (let i = 0; i < 11; i++) {
    //         newData.push({
    //             uuid: 'd0b96e26-c125-4003-a8b1-3921daf8fc07',
    //             newVoltage: this.generateRandomNumber(11.5, 12.5),
    //             createdBy: new Date().toLocaleString(),
    //         })
    //     }
    //     return newData;
    // }
    //
    // generateRandomNumber(min: number, max: number) {
    //     return (Math.random() * (max - min) + min).toFixed(2);
    // };
}
