export const enum EntityType {
    Voltage = 1,
    Temperature = 2,
}

export const enum OnEventSocket {
    RequestUpdateVoltage = 'requestUpdateVoltage',
    RequestUpdateTemperature = 'requestUpdateTemperature',
    RequestUpdateLocation = 'requestUpdateGps',
}

export const enum EmitEventSocket {
    ResponseUpdateVoltage = 'responseUpdateVoltage',
    ResponseUpdateTemperature = 'responseUpdateTemperature',
    ResponseUpdateLocation = 'responseUpdateGps',
}
