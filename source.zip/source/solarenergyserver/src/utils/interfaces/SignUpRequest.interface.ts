export interface SignUpRequestInterface {
    username: string;
    email: string;
    password: string;
}
