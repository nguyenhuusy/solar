export interface EntityDataInterface {
    uuid: string;
    voltage?: number;
    temperature?: number;
}
