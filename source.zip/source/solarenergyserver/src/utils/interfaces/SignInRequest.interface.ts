export interface SignInRequestInterface {
    username: string;
    password: string;
}
