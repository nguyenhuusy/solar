import express from 'express'
import {AuthController} from '../controllers/AuthController';
import {LocationController} from '../controllers/LocationController';
import {EntityController} from '../controllers/EntityController';
import {VoltageController} from '../controllers/VoltageController';
import {TemperatureController} from '../controllers/TemperatureController';

export function RegisterRoutes(app: express.Application) {
    app.post('/auth/sign-in', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const controller = new AuthController();
        const promise = controller.login(req.body);
        promiseHandler(controller, promise, res, next).then();
    });

    app.post('/auth/register', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const controller = new AuthController();
        const promise = controller.registerUser(req.body);
        promiseHandler(controller, promise, res, next).then();
    });

    app.get('/locations', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const controller = new LocationController();
        const promise = controller.getLocations();
        promiseHandler(controller, promise, res, next).then();
    });

    app.get('/entities', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const controller = new EntityController();
        const promise = controller.getEntitiesByQuery(req.query);
        promiseHandler(controller, promise, res, next).then();
    });

    app.get('/voltages', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const controller = new VoltageController();
        const promise = controller.getVoltages(req.query.uuid, +req.query.limit);
        promiseHandler(controller, promise, res, next).then();
    });

    app.get('/temperatures', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const controller = new TemperatureController();
        const promise = controller.getTemperatures(req.query.uuid, +req.query.limit);
        promiseHandler(controller, promise, res, next).then();
    });

    function promiseHandler(controllerObj: any, promise: any, response: any, next: any) {
        return Promise.resolve(promise)
            .then((data: any) => {
                if (data) {
                    response.status(200).json(data);
                } else {
                    response.status(204).end();
                }
            })
            .catch((error: any) => response.status(500).json(error));
    }
}
