import {Server, createServer} from 'http';
import express from 'express';
import socketIo from 'socket.io';
import dotenv from 'dotenv';
import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose, {Mongoose} from 'mongoose';
import passport from 'passport';
import config from 'config';
import {MongoError} from 'mongodb';
import {authenticateUser} from './middlewares/security/passport';
import {RegisterRoutes} from './routes/routes';
import {EntityController} from './controllers/EntityController';
import {LocationController} from './controllers/LocationController';
import {VoltageController} from './controllers/VoltageController';
import {TemperatureController} from './controllers/TemperatureController';

export class App {
    private app: express.Application;
    private server: Server;
    private io: socketIo.Server;
    private port: number | string | boolean;
    private mongooseConnection: mongoose.Connection;
    private _entityController = new EntityController();
    private _locationController = new LocationController();
    private _voltageController = new VoltageController();
    private _temperatureController = new TemperatureController();

    constructor() {
        this.createApp();
        this.connectDatabase();
        this.configure();
        this.createServer();
        this.createSockets();
        this.listen();
        this.routes();
    }

    private createApp(): void {
        this.app = express();
    }

    private configure(): void {
        dotenv.config();
        this.port = App.normalizePort(process.env.PORT || config.get('express.port'));

        this.app.use(cors());
        this.app.options('*', cors());

        this.app.use(bodyParser.json());
        this.app.use(bodyParser.urlencoded({
            extended: false,
            limit: '5mb',
            parameterLimit: 5000
        }));

        this.app.use(passport.initialize());
        this.app.use(passport.session());
        authenticateUser(passport);

        this.app.get('/', (req: express.Request, res: express.Response) => {
            res.send('Server worked');
        });
    }

    private createServer(): void {
        this.server = createServer(this.app);
    }

    private createSockets(): void {
        this.io = socketIo(this.server);
    }

    private connectDatabase(): void {
        (mongoose as Mongoose).Promise = global.Promise;
        mongoose.connect(process.env.MONGO_URI || config.get('mongo.mongo_uri'), {useNewUrlParser: true}).then(
            () => {
                this.mongooseConnection = mongoose.connection;
                App.onMongoConnection();
            }).catch(
            (error: MongoError) => {
                App.onMongoConnectionError(error);
            });
    }

    private listen(): void {
        this.server.listen(this.port, () => {
            console.log('Running server on port %s.', this.port);
        });

        this.io.on('connect', (socket: any) => {
            console.log('Connected client on port %s.', this.port);

            this._entityController.handleEvent(socket);
            this._locationController.handleEvent(socket);
            this._voltageController.handleEvent(socket);
            this._temperatureController.handleEvent(socket);

            socket.on('disconnect', () => {
                console.log('Client disconnected');
            });
        });
    }

    private routes(): void {
        RegisterRoutes(this.app);
    }

    private static normalizePort(param: number | string): number | string | boolean {
        const portNumber: number = typeof param === 'string' ? parseInt(param, 10) : param;
        if (isNaN(portNumber)) return param;
        else if (portNumber >= 0) return portNumber;
        else return false;
    }

    private static onMongoConnection(): void {
        console.log('Connected to database.');
    }

    private static onMongoConnectionError(error: MongoError): void {
        console.log(`Error on connection to database: ${error}`);
    }

    public getApp(): express.Application {
        return this.app;
    }
}
