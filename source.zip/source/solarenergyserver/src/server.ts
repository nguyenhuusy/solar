import {App} from './app';

let app = new App().getApp();

export {app};
