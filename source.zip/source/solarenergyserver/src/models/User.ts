import {Document, Model, model, Schema} from "mongoose";

export const UserSchema = new Schema({
    username: String,
    password: String,
    email: String,
}, {
    collection: 'users'
});

export interface UserInterface extends Document {
    username: string;
    password: string;
    email: string;
}

export type UserModel = Model<UserInterface>;
export const User: UserModel = model<UserInterface>('User', UserSchema) as UserModel;
