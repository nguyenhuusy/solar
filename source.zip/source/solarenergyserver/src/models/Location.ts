import {Document, Model, model, Schema} from "mongoose";

export const LocationSchema = new Schema({
    uuid: String,
    updatedBy: String,
    latitude: Number,
    longitude: Number,
}, {
    collection: 'locations'
});

export interface LocationInterface extends Document {
    uuid: string;
    updatedBy: string;
    latitude: number;
    longitude: number;
}

export type LocationModel = Model<LocationInterface>;
export const Location: LocationModel = model<LocationInterface>('Location', LocationSchema) as LocationModel;
