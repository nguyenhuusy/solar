import {Document, Model, model, Schema} from "mongoose";

export const VoltageSchema = new Schema({
    newVoltage: Number,
    createdBy: String,
    uuid: String,
}, {
    collection: 'voltage'
});

export interface VoltageInterface extends Document {
    uuid: string;
    createdBy: string;
    newVoltage: number;
}

export type VoltageModel = Model<VoltageInterface>;
export const Voltage: VoltageModel = model<VoltageInterface>('Voltage', VoltageSchema) as VoltageModel;
