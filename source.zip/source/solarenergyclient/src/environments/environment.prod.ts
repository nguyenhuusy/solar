export const environment = {
  production: true,
  url: 'https://solarenergyserver.herokuapp.com',
  apiKeyMap: 'AIzaSyBvMFNe8k500VmteA4VUeSZuRuOMV1Kqto',
};
