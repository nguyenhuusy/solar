import {RouterModule, Route} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

const routes: Route[] = [
    {
        path: '',
        loadChildren: './main-layout/main-layout.module#MainLayoutModule',
    },
    {
        path: 'signIn',
        loadChildren: './authentication/authentication.module#AuthenticationModule',
    },
];

export const AppRoutes: ModuleWithProviders = RouterModule.forRoot(routes);
