import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Observable, ReplaySubject} from 'rxjs';
import {JwtService} from './jwt.service';
import {SignInInterface, SignUpInterface} from './interfaces';
import {environment} from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})

export class AuthenticationService {
    private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
    public isAuthenticated = this.isAuthenticatedSubject.asObservable();

    constructor(
        private http: HttpClient
    ) { }

    attemptAuth(credentials: SignInInterface): Observable<any> {
        return this.http.post(`${environment.url}/auth/sign-in`, credentials).pipe(map((response: any) => {
            this.setAuth(response);
            return response;
        }));
    }

    attemptRegister(credentials: SignUpInterface): Observable<any> {
        return this.http.post('user/register', credentials).pipe(map((response: any) => {
            JwtService.saveToken(response.token);
            return response;
        }));
    }

    private setAuth(user: any) {
        JwtService.saveToken(user.token);
        this.isAuthenticatedSubject.next(true);
    }

    private purgeAuth() {
        JwtService.destroyToken();
        this.isAuthenticatedSubject.next(false);
    }

    signOut() {
        this.purgeAuth();
    }
}
