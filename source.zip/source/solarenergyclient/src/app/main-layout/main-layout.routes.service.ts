import {Map1Component} from '../views/maps/map1/map1.component';
import {BasicTableComponent} from '../views/tables/basic-table/basic-table.component';
import {Profile1Component} from '../views/profile/profile1/profile1.component';
import {RouterModule, Route} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {NotFoundComponent} from '../views/errors/not-found/not-found.component';
import {Dashboard1Component} from '../views/dashboards/dashboard1/dashboard1.component';
import {MainLayoutComponent} from './main-layout.component';
import {AuthGuard} from '../shared/guards/auth.guard';
import {CurrentComponent} from '../views/current/current.component';

const routes: Route[] = [
    {
        path: '',
        component: MainLayoutComponent,
        canActivate: [AuthGuard],
        children: [
            {path: '', pathMatch: 'full', redirectTo: 'dashboards'},
            {path: 'dashboards', component: Dashboard1Component},
            {path: 'maps', component: Map1Component},
            {path: 'charts', component: Profile1Component},
            {path: 'statistic', component: BasicTableComponent},
            {path: 'today', component: CurrentComponent},
            {path: '**', component: NotFoundComponent},
        ]
    }
];

export const MainLayoutRoutes: ModuleWithProviders = RouterModule.forChild(routes);
