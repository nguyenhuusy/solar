import {NgModule} from '@angular/core';
import {MainLayoutComponent} from './main-layout.component';
import {MainLayoutRoutes} from './main-layout.routes.service';
import {NavigationModule} from './navigation/navigation.module';
import {FooterComponent} from './footer/footer.component';
import {CommonModule} from '@angular/common';
import {SharedModule} from '../shared/shared.module';

@NgModule({
    imports: [
        CommonModule,
        MainLayoutRoutes,
        NavigationModule,
        SharedModule
    ],
    declarations: [
        MainLayoutComponent,
        FooterComponent,
    ],
    exports: [],
})

export class MainLayoutModule {
}
