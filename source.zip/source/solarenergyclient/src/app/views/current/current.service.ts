import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {environment} from '../../../environments/environment';
import * as socketio from 'socket.io-client';
import {from, Subject} from 'rxjs';

@Injectable()

export class CurrentService {
    constructor(
        private http: HttpClient
    ) {
    }

    getVoltages(uuid: string, limit: number) {
        const httpParams = {
            params: new HttpParams().set('uuid', uuid).set('limit', limit.toString())
        };
        return this.http.get(`${environment.url}/voltages`, httpParams);
    }

    getTemperatures(uuid: string, limit: number) {
        const httpParams = {
            params: new HttpParams().set('uuid', uuid).set('limit', limit.toString())
        };
        return this.http.get(`${environment.url}/temperatures`, httpParams);
    }

    initSocket(type: number) {
        const socket = socketio(environment.url);
        const voltageSubscribe = new Subject();
        const voltageObservable = from(voltageSubscribe);
        const temperatureSubscribe = new Subject();
        const temperatureObservable = from(temperatureSubscribe);

        socket.on('updateVoltage', (data: any) => {
            voltageSubscribe.next(data);
        });

        socket.on('updateTemperature', (data: any) => {
            temperatureSubscribe.next(data);
        });

        return type === 1 ? voltageObservable : temperatureObservable;
    }
}
