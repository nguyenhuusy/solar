import {Component, OnInit} from '@angular/core';
import {StatisticsService} from '../../tables/statistics.service';
import {MapsService} from '../../maps/maps.service';
import * as _ from 'underscore';

@Component({
    selector: 'app-profile1',
    templateUrl: './profile1.component.html',
    styleUrls: ['./profile1.component.scss']
})
export class Profile1Component implements OnInit {
    public dataVoltages: Array<any> = [
        {data: [], label: 'Voltage'},
    ];
    public dataTemperatures: Array<any> = [
        {data: [], label: 'Temperature'},
    ];
    public chartLabelsVoltage: Array<any> = [];
    public chartLabelsTemperature: Array<any> = [];
    public chartColorsVoltage: Array<any> = [{
        backgroundColor: 'rgba(105, 0, 132, .2)',
        borderColor: 'rgba(200, 99, 132, .7)',
        borderWidth: 2,
    }];
    public chartColorsTemperature: Array<any> = [{
        backgroundColor: 'rgba(0, 137, 132, .2)',
        borderColor: 'rgba(0, 10, 130, .7)',
        borderWidth: 2,
    }];
    public chartOptions: any = {
        responsive: true,
        legend: {
            labels: {
                fontColor: '#5b5f62',
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    fontColor: '#5b5f62',
                }
            }],
            xAxes: [{
                ticks: {
                    fontColor: '#5b5f62',
                }
            }]
        }
    };

    stationsList: any[] = [];
    monthsList = [
        {name: 'January', value: '01'},
        {name: 'February', value: '02'},
        {name: 'March', value: '03'},
        {name: 'April', value: '04'},
        {name: 'May', value: '05'},
        {name: 'June', value: '06'},
        {name: 'July', value: '07'},
        {name: 'August', value: '08'},
        {name: 'September', value: '09'},
        {name: 'October', value: '10'},
        {name: 'November', value: '11'},
        {name: 'December', value: '12'},
    ];
    currentStationVoltage: string;
    currentMonthVoltage: string;
    currentStationTemperature: string;
    currentMonthTemperature: string;

    constructor(
        private service: StatisticsService,
        private mapsService: MapsService,
    ) {
        this.currentMonthVoltage = this.monthsList[4].value;
        this.currentMonthTemperature = this.monthsList[4].value;
    }

    ngOnInit() {
        this.getLocationsList();
    }

    getLocationsList() {
        this.mapsService.getLocations().subscribe(
            async (data: any) => {
                this.stationsList = data;
                this.currentStationVoltage = this.stationsList[0].uuid;
                this.currentStationTemperature = this.stationsList[0].uuid;
                this.getVoltages();
                this.getTemperatures();
            },
            async err => {
                console.error(err);
            });
    }

    getVoltages() {
        this.service.getEntities({stationUuid: this.currentStationVoltage, type: 1}).subscribe(
            async (data: any) => {
                let monthData = data.filter((item: any) => item.createdBy.split('-')[0] === this.currentMonthVoltage);
                monthData = _.sortBy(monthData, 'createdBy');
                this.chartLabelsVoltage = monthData.map((item: any) => item.createdBy);
                this.dataVoltages[0].data = monthData.map((item: any) => item.value);
            },
            async err => {
                console.error(err);
            });
    }

    getTemperatures() {
        this.service.getEntities({stationUuid: this.currentStationVoltage, type: 2}).subscribe(
            async (data: any) => {
                let monthData = data.filter((item: any) => item.createdBy.split('-')[0] === this.currentMonthTemperature);
                monthData = _.sortBy(monthData, 'createdBy');
                this.chartLabelsTemperature = monthData.map((item: any) => item.createdBy);
                this.dataTemperatures[0].data = monthData.map((item: any) => item.value);
            },
            async err => {
                console.error(err);
            });
    }

    onVoltageStationSelectChange() {
        this.getVoltages();
    }

    onVoltageMonthChange() {
        this.getVoltages();
    }

    onTemperatureStationSelectChange() {
        this.getTemperatures();
    }

    onTemperatureMonthChange() {
        this.getTemperatures();
    }
}
