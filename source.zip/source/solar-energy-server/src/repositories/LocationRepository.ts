import {ILocation, LocationModel} from "../models/Location";
import {ILocationRepository} from "./ILocationRepository";

export class LocationRepository implements ILocationRepository {
    private _locationModel: LocationModel;

    constructor(locationModel: LocationModel) {
        this._locationModel = locationModel;
    }

    async createLocation(newLocation: ILocation): Promise<ILocation> {
        return await this._locationModel.create(newLocation);
    }

    async getLocationByUuid(uuid: string): Promise<ILocation> {
        const query = {uuid};
        return await this._locationModel.findOne(query);
    }

    async updateLocation(uuid: string, updatedLocation: ILocation): Promise<ILocation> {
        const fetchLocation = await this._locationModel.findOne({uuid});
        fetchLocation.lat = updatedLocation.lat;
        fetchLocation.long = updatedLocation.long;
        return await fetchLocation.save();
    }
}
