import {Application} from 'express';
import * as winston from 'winston';
import {Logger} from 'winston';
import {get} from 'config';

export const winstonLogger: Logger = winston.createLogger();

process.on('unhandledRejection', (reason, p) => {
    winstonLogger.warn('Possibly Unhandled Rejection at: Promise ', p, ' reason: ', reason);
});

const level: string = process.env.LOG_LEVEL || get('loglevel');

export function setupLogging(app: Application) {
    /**
     * Development Logger
     * const env = server-config.util.getEnv('NODE_ENV');
     * error: 0, warn: 1, info: 2, verbose: 3, debug: 4, silly: 5
     */

    if (level === 'info') {
        winstonLogger.add(winston.transports.Console);
    }
}
