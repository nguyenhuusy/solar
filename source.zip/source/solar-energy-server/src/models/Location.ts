import {Document, Model, model, Schema} from "mongoose";

export const LocationSchema = new Schema({
    createdBy: String,
    lat: Number,
    long: Number,
}, {
    collection: 'location'
});

export interface ILocation extends Document {
    createdBy: String,
    lat: Number,
    long: Number,
}

export type LocationModel = Model<ILocation>;
export const Location: LocationModel = model<ILocation>('Location', LocationSchema) as LocationModel;
