import {Document, Model, model, Schema} from "mongoose";

export const TemperatureSchema = new Schema({
    createdBy: String,
    newTemperature: Number,
    uuid: String,
}, {
    collection: 'temperature'
});

export interface ITemperature extends Document {
    createdBy: String,
    newTemperature: Number,
    uuid: String,
}

export type TemperatureModel = Model<ITemperature>;
export const Temperature: TemperatureModel = model<ITemperature>('Temperature', TemperatureSchema) as TemperatureModel;
