export interface INewUserRequest {
    username: string;
    email: string;
    password: string;
}
