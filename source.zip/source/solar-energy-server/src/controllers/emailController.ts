import * as nodemailer from 'nodemailer';
import {get} from 'config';

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: get('mail.username'),
        pass: get('mail.password'),
    },
});

export class EmailController {
    async sendMail() {
        const mailOptions = {
            to: "41204560@hcmut.edu.vn",
            from: get('mail.username').toString(),
            subject: "Contact Form",
            text: 'This is auto email to inform that it maybe have some problem with your system. Please check!',
        };

        transporter.sendMail(mailOptions, (err) => {
            if (err) {
                console.log(err);
            }
            console.log('message: success');
        });
    }
}
