const data3 = {
    year: 2019,
    month: 3,
    data: [
        {
            "date": "01-03-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "02-03-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "03-03-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "04-03-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "05-03-2019",
            "voltage": 10,
            "temperature": 30
        },
        {
            "date": "06-03-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "07-03-2019",
            "voltage": 13,
            "temperature": 28
        },
        {
            "date": "08-03-2019",
            "voltage": 11,
            "temperature": 30
        },
        {
            "date": "09-03-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "10-03-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "11-03-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "12-03-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "13-03-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "14-03-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "15-03-2019",
            "voltage": 10,
            "temperature": 28
        },
        {
            "date": "16-03-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "17-03-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "18-03-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "19-03-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "20-03-2019",
            "voltage": 10,
            "temperature": 30
        },
        {
            "date": "21-03-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "22-03-2019",
            "voltage": 12,
            "temperature": 30
        },
        {
            "date": "23-03-2019",
            "voltage": 10,
            "temperature": 32
        },
        {
            "date": "24-03-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "25-03-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "26-03-2019",
            "voltage": 10,
            "temperature": 32
        },
        {
            "date": "27-03-2019",
            "voltage": 10,
            "temperature": 30
        },
        {
            "date": "28-03-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "29-03-2019",
            "voltage": 12,
            "temperature": 28
        },
        {
            "date": "30-03-2019",
            "voltage": 12,
            "temperature": 30
        },
        {
            "date": "31-03-2019",
            "voltage": 11,
            "temperature": 31
        }
    ]
};

export default data3;
