import data1 from './data-1';
import data2 from "./data-2";
import data3 from "./data-3";
import data4 from "./data-4";
import data5 from "./data-5";
import data6 from "./data-6";
import data7 from './data-7';
import data8 from './data-8';
import data9 from './data-9';
import data10 from './data-10';

const data = [
    {
        uuid: '9e4052c9-cdd1-45af-9174-96dbaa1fd40e',
        statistics: [
            data1,
            data2,
            data3,
            data4,
            data5
        ]
    },
    {
        uuid: 'e95d468b-8973-47a6-8700-4b2c538f38d5',
        statistics: [
            data6,
            data7,
            data8,
            data9,
            data10
        ]
    }
];

export default data;
