const data7 = {
    year: 2019,
    month: 2,
    data: [
        {
            "date": "01-02-2019",
            "voltage": 12,
            "temperature": 31
        },
        {
            "date": "02-02-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "03-02-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "04-02-2019",
            "voltage": 10,
            "temperature": 28
        },
        {
            "date": "05-02-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "06-02-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "07-02-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "08-02-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "09-02-2019",
            "voltage": 10,
            "temperature": 28
        },
        {
            "date": "10-02-2019",
            "voltage": 10,
            "temperature": 28
        },
        {
            "date": "11-02-2019",
            "voltage": 12,
            "temperature": 30
        },
        {
            "date": "12-02-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "13-02-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "14-02-2019",
            "voltage": 12,
            "temperature": 28
        },
        {
            "date": "15-02-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "16-02-2019",
            "voltage": 13,
            "temperature": 28
        },
        {
            "date": "17-02-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "18-02-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "19-02-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "20-02-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "21-02-2019",
            "voltage": 12,
            "temperature": 30
        },
        {
            "date": "22-02-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "23-02-2019",
            "voltage": 12,
            "temperature": 31
        },
        {
            "date": "24-02-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "25-02-2019",
            "voltage": 10,
            "temperature": 30
        },
        {
            "date": "26-02-2019",
            "voltage": 12,
            "temperature": 31
        },
        {
            "date": "27-02-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "28-02-2019",
            "voltage": 11,
            "temperature": 29
        }
    ]
};

export default data7;
