import {Component, OnInit} from '@angular/core';
import {MapsService} from '../maps/maps.service';
import {CurrentService} from './current.service';
import * as _ from 'underscore';

@Component({
    selector: 'app-current',
    templateUrl: 'current.component.html',
    providers: [CurrentService]
})

export class CurrentComponent implements OnInit {
    voltageData: any[] = [];
    temperatureData: any[] = [];
    stationsList: any[] = [];
    monthsList = [
        {name: 'January', value: '01'},
        {name: 'February', value: '02'},
        {name: 'March', value: '03'},
        {name: 'April', value: '04'},
        {name: 'May', value: '05'},
        {name: 'June', value: '06'},
        {name: 'July', value: '07'},
        {name: 'August', value: '08'},
        {name: 'September', value: '09'},
        {name: 'October', value: '10'},
        {name: 'November', value: '11'},
        {name: 'December', value: '12'},
    ];
    currentStationVoltage: string;
    currentMonthVoltage: string;

    public dataVoltages: Array<any> = [
        {data: [], label: 'Voltage'},
    ];
    public dataTemperatures: Array<any> = [
        {data: [], label: 'Temperature'},
    ];
    public chartLabelsVoltage: Array<any> = [];
    public chartLabelsTemperature: Array<any> = [];
    public chartColorsVoltage: Array<any> = [{
        backgroundColor: 'rgba(105, 0, 132, .2)',
        borderColor: 'rgba(200, 99, 132, .7)',
        borderWidth: 2,
    }];
    public chartColorsTemperature: Array<any> = [{
        backgroundColor: 'rgba(0, 137, 132, .2)',
        borderColor: 'rgba(0, 10, 130, .7)',
        borderWidth: 2,
    }];
    public chartOptions: any = {
        responsive: true,
        legend: {
            labels: {
                fontColor: '#5b5f62',
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    fontColor: '#5b5f62',
                }
            }],
            xAxes: [{
                ticks: {
                    fontColor: '#5b5f62',
                }
            }]
        }
    };

    constructor(
        private service: CurrentService,
        private locationsService: MapsService,
    ) {
        if (!this.currentMonthVoltage) {
            this.currentMonthVoltage = this.monthsList[0].value;
        }
    }

    ngOnInit() {
        this.getStationsList();
    }

    getStationsList() {
        this.locationsService.getLocations().subscribe(
            async (data: any) => {
                this.stationsList = data;
                if (!this.currentStationVoltage) {
                    this.currentStationVoltage = this.stationsList[0].uuid;
                }
                setInterval(() => {
                    this.getVoltages();
                    this.getTemperatures();
                }, 5000);
            },
            async (err: any) => {
                console.error(err);
            });
    }

    getVoltages() {
        this.service.getVoltages(this.currentStationVoltage, 10).subscribe(
            async (data: any) => {
                this.voltageData = data;
                this.dataVoltages[0].data = _.sortBy(data, 'createdBy').map((item: any) => item.newVoltage);
                this.chartLabelsVoltage = _.sortBy(data, 'createdBy').map((item: any) => item.createdBy);
            },
            async (err: any) => {
                console.error(err);
            });
    }

    getTemperatures() {
        this.service.getTemperatures(this.currentStationVoltage, 10).subscribe(
            async (data: any) => {
                this.temperatureData = data;
                this.dataTemperatures[0].data = _.sortBy(data, 'createdBy').map((item: any) => item.newTemperature);
                this.chartLabelsTemperature = _.sortBy(data, 'createdBy').map((item: any) => item.createdBy);
            },
            async (err: any) => {
                console.error(err);
            });
    }
}
