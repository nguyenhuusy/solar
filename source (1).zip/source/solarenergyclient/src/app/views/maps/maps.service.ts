import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../environments/environment';
import * as socketio from 'socket.io-client';
import {from, Subject} from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class MapsService {
    constructor(
        private http: HttpClient
    ) {
    }

    getLocations() {
        return this.http.get(`${environment.url}/locations`);
    }

    initSocket() {
        const socket = socketio(environment.url);
        const locationSubscribe = new Subject();
        const locationObservable = from(locationSubscribe);

        socket.on('responseUpdateGps', (data: any) => {
            locationSubscribe.next(data);
        });

        return locationObservable;
    }
}
