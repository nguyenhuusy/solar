import {Component, OnInit} from '@angular/core';
import {MapsService} from '../maps.service';

@Component({
    selector: 'app-map1',
    templateUrl: './map1.component.html',
    styleUrls: ['./map1.component.scss']
})
export class Map1Component implements OnInit {
    public map: any = {lat: 51.678418, lng: 7.809007};
    public locationsList: any[];

    constructor(
        private service: MapsService
    ) {
    }

    ngOnInit() {
        this.getLocations();
    }

    getLocations() {
        this.service.getLocations().subscribe(
            async (data: any) => {
                this.locationsList = data.map((item: any, index: number) => {
                    item.name = `Station ${index + 1}`;
                    return item;
                });
                this.initSocket();
            },
            async err => {
                console.error(err);
            });
    }

    private initSocket() {
        this.service.initSocket().subscribe(
            async (data: any) => {
                if (data.isSuccess) {
                    const updatedLocation = this.locationsList.find(location => location.uuid === data.uuid);
                    updatedLocation.latitude = data.latitude;
                    updatedLocation.longitude = data.longitude;
                }
            },
            async err => {
                console.error(err);
            });
    }
}
