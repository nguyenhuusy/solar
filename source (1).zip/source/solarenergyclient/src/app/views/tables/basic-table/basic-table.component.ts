import {Component, OnInit} from '@angular/core';
import {StatisticsService} from '../statistics.service';
import {MapsService} from '../../maps/maps.service';

@Component({
    selector: 'app-basic-table',
    templateUrl: './basic-table.component.html',
    styleUrls: ['./basic-table.component.scss'],
})

export class BasicTableComponent implements OnInit {
    stationsList: any[] = [];
    monthsList = [
        {name: 'January', value: '01'},
        {name: 'February', value: '02'},
        {name: 'March', value: '03'},
        {name: 'April', value: '04'},
        {name: 'May', value: '05'},
        {name: 'June', value: '06'},
        {name: 'July', value: '07'},
        {name: 'August', value: '08'},
        {name: 'September', value: '09'},
        {name: 'October', value: '10'},
        {name: 'November', value: '11'},
        {name: 'December', value: '12'},
    ];
    currentStationVoltage: string;
    currentMonthVoltage: string;
    currentStationTemperature: string;
    currentMonthTemperature: string;

    voltagesData = [];
    headElementsVoltage = ['ID', 'Date', 'Voltage'];

    temperaturesData = [];
    headElementsTemperature = ['ID', 'Date', 'Temperature'];

    constructor(
        private service: StatisticsService,
        private mapsService: MapsService,
    ) {
        if (!this.currentMonthVoltage) {
            this.currentMonthVoltage = this.monthsList[4].value;
        }
        if (!this.currentMonthTemperature) {
            this.currentMonthTemperature = this.monthsList[4].value;
        }
    }

    ngOnInit() {
        this.getLocationsList();
    }

    getLocationsList() {
        this.mapsService.getLocations().subscribe(
            async (data: any) => {
                this.stationsList = data;
                if (!this.currentStationVoltage) {
                    this.currentStationVoltage =  this.stationsList[0].uuid;
                }
                if (!this.currentStationTemperature) {
                    this.currentStationTemperature = this.stationsList[0].uuid;
                }
                this.getVoltages();
                this.getTemperatures();
            },
            async err => {
                console.error(err);
            });
    }

    getVoltages() {
        this.service.getEntities({stationUuid: this.currentStationVoltage, type: 1}).subscribe(
            async (data: any) => {
                this.voltagesData = data.filter((item: any) => item.createdBy.split('-')[0] === this.currentMonthVoltage);
            },
            async err => {
                console.error(err);
            });
    }

    getTemperatures() {
        this.service.getEntities({stationUuid: this.currentStationTemperature, type: 2}).subscribe(
            async (data: any) => {
                this.temperaturesData = data.filter((item: any) => item.createdBy.split('-')[0] === this.currentMonthTemperature);
            },
            async err => {
                console.error(err);
            });
    }

    onVoltageStationSelectChange(event: any) {
        this.currentStationVoltage = event;
        this.getVoltages();
    }

    onVoltageMonthChange(event: any) {
        this.currentMonthVoltage = event;
        this.getVoltages();
    }

    onTemperatureStationSelectChange(event: any) {
        this.currentStationTemperature = event;
        this.getTemperatures();
    }

    onTemperatureMonthChange(event: any) {
        this.currentMonthTemperature = event;
        this.getTemperatures();
    }
}
