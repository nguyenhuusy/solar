import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {environment} from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})

export class StatisticsService {
    constructor(
        private http: HttpClient
    ) {
    }

    getEntities(params: { stationUuid: string, type: number, limit?: number }) {
        let httpParams: any;
        if (params.limit) {
            httpParams = {
                params: new HttpParams()
                    .set('stationUuid', params.stationUuid)
                    .set('type', params.type.toString())
                    .set('limit', params.limit.toString())
            };
        } else {
            httpParams = {
                params: new HttpParams().set('stationUuid', params.stationUuid).set('type', params.type.toString())
            };
        }
        return this.http.get(`${environment.url}/entities`, httpParams);
    }
}
