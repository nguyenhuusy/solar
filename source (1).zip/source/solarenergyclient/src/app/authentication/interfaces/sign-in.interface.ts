export interface SignInInterface {
    username: string;
    password: string;
}
