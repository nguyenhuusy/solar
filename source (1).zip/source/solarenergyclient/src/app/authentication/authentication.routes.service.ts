import {RouterModule, Route} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {SignInComponent} from './sign-in/sign-in.component';
import {SignUpComponent} from './sign-up/sign-up.component';

const routes: Route[] = [
    {
        path: 'signIn',
        component: SignInComponent
    },
    {
        path: 'signUp',
        component: SignUpComponent
    }
];

export const AuthenticationRoutes: ModuleWithProviders = RouterModule.forChild(routes);
