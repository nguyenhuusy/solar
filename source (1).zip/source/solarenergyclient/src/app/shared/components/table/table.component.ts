import {
    AfterViewInit,
    ChangeDetectorRef,
    Component, EventEmitter,
    HostListener,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild
} from '@angular/core';
import {TableInputInterface} from './table-input.interface';
import {MdbTableDirective, MdbTablePaginationComponent} from 'angular-bootstrap-md';

@Component({
    selector: 'app-table',
    templateUrl: 'table.component.html',
})

export class TableComponent implements OnInit, OnChanges, AfterViewInit {
    @Input() input: TableInputInterface;
    @Output() onChangeStation = new EventEmitter();
    @Output() onChangeMonth = new EventEmitter();
    stationsList: any[] = [];
    monthsList: any[] = [];
    currentStation: string;
    currentMonth: string;

    @ViewChild(MdbTableDirective) mdbTable: MdbTableDirective;
    @ViewChild(MdbTablePaginationComponent) mdbTablePagination: MdbTablePaginationComponent;
    data: any[];
    headElements: string[];
    searchText = '';
    previous: string;

    @HostListener('input', ['$event']) oninput() {
        this.search();
    }

    constructor(
        private cdRef: ChangeDetectorRef
    ) {

    }

    ngOnInit() {
    }

    ngAfterViewInit() {
        this.mdbTablePagination.setMaxVisibleItemsNumberTo(5);
        this.mdbTablePagination.calculateFirstItemIndex();
        this.mdbTablePagination.calculateLastItemIndex();
        this.cdRef.detectChanges();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (!changes.firstChange) {
            this.data = this.input.data;
            this.headElements = this.input.headElements;
            this.mdbTable.setDataSource(this.data);
            this.data = this.mdbTable.getDataSource();
            this.previous = this.mdbTable.getDataSource();
            this.stationsList = this.input.stationsList;
            this.monthsList = this.input.monthsList;
            if (this.stationsList.length > 0) {
                this.currentStation = this.stationsList[0].uuid;
            }
            if (this.monthsList.length > 0) {
                this.currentMonth = this.monthsList[4]['value'];
            }
        }
    }

    search() {
        const prev = this.mdbTable.getDataSource();

        if (!this.searchText) {
            this.mdbTable.setDataSource(this.previous);
            this.data = this.mdbTable.getDataSource();
        }

        if (this.searchText) {
            this.data = this.mdbTable.searchLocalDataBy(this.searchText);
            this.mdbTable.setDataSource(prev);
        }
    }

    onStationChange() {
        this.onChangeStation.emit(this.currentStation);
    }

    onMonthChange() {
        this.onChangeMonth.emit(this.currentMonth);
    }
}
