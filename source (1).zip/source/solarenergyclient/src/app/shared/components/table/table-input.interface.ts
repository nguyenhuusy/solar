export interface TableInputInterface {
    title: string;
    id: string;
    data: any[];
    headElements: string[];
    stationsList: any[];
    monthsList: any[];
    currentStation: string;
    currentMonth: string;
}

