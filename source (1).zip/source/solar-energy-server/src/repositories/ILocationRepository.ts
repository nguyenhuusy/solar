import {ILocation} from "../models/Location";

export interface ILocationRepository {
    createLocation(newLocation: ILocation): void;

    getLocationByUuid(uuid: string): void;

    updateLocation(uuid: string, updatedLocation: ILocation): void;
}
