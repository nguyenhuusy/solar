import {Document, Model, model, Schema} from "mongoose";

export const VoltageSchema = new Schema({
    createdBy: String,
    newVoltage: Number,
    uuid: String,
}, {
    collection: 'voltage'
});

export interface IVoltage extends Document {
    createdBy: String,
    newVoltage: Number,
    uuid: String,
}

export type VoltageModel = Model<IVoltage>;
export const Voltage: VoltageModel = model<IVoltage>('Voltage', VoltageSchema) as VoltageModel;
