export interface ILoginResponse {
    token: string;
}
