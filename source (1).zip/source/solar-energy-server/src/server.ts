import http from 'http';
import {get} from 'config';
import socketIO from 'socket.io'

import App from './app';
import {winstonLogger} from "./middlewares/common/WinstonLogger";
import {EmailController} from "./controllers/emailController";
import {Voltage} from "./models/Voltage";
import {Temperature} from "./models/Temperature";
import {Location} from "./models/Location";
import {LocationRepository} from "./repositories/LocationRepository";

const port = normalizePort(process.env.PORT || get('express.port'));
const server = http.createServer(App.app);

server.listen(port);

server.on('error', onServerError);
server.on('listening', onServerListening);

let _locationRepository = new LocationRepository(Location);

const io = require('socket.io').listen(server);
io.on("connection", (socket: socketIO.Socket) => {
    winstonLogger.info('-----A user connected');

    socket.on('connection', (data) => {
        socket.emit('responseRequestConnection', JSON.stringify({
            uuid: data.uuid,
            status: 'Success',
            updatedOn: Date.now(),
            type: 'Request Connection'
        }));
    });

    socket.on('requestUpdateVoltage', async (data) => {
        if (data.voltage < 2) {
            const controller = new EmailController();
            controller.sendMail()
                .then(() => {
                    winstonLogger.info('-----Warning voltage');
                })
                .catch(error => {
                    winstonLogger.error(error);
                })
        }

        const newData = new Voltage();
        newData.newVoltage = data.voltage;
        newData.createdBy = new Date().toLocaleString();
        newData.uuid = data.uuid;
        await newData.save(data, (err: any, result: any) => {
            if (err) {
                socket.emit('responseUpdateVoltage', JSON.stringify({
                    uuid: data.uuid,
                    status: 'Failure',
                    updatedOn: Date.now(),
                    type: 'Voltage'
                }));
                throw err;
            }
            socket.emit('responseUpdateVoltage', JSON.stringify({
                uuid: data.uuid,
                status: 'Success',
                updatedOn: Date.now(),
                type: 'Voltage'
            }));
        });
    });

    socket.on('requestUpdateGps', async (data) => {
        const newData = await _locationRepository.getLocationByUuid(data.uuid);
        console.log('GPS', data);
        if (newData) {
            await _locationRepository.updateLocation(data.uuid, data)
                .then(() => {
                    socket.emit('responseUpdateGps', JSON.stringify({
                        uuid: data.uuid,
                        status: 'Success',
                        updatedOn: Date.now(),
                        type: 'GPS'
                    }));
                })
                .catch(error => {
                    socket.emit('responseUpdateGps', JSON.stringify({
                        uuid: data.uuid,
                        status: 'Failure',
                        updatedOn: Date.now(),
                        type: 'GPS'
                    }));
                    throw error;
                })
        } else {
            await _locationRepository.createLocation(data)
                .then(() => {
                    socket.emit('responseUpdateGps', JSON.stringify({
                        uuid: data.uuid,
                        status: 'Success',
                        updatedOn: Date.now(),
                        type: 'GPS'
                    }));
                })
                .catch(error => {
                    socket.emit('responseUpdateGps', JSON.stringify({
                        uuid: data.uuid,
                        status: 'Failure',
                        updatedOn: Date.now(),
                        type: 'GPS'
                    }));
                    throw error;
                })
        }
    });

    socket.on('requestUpdateTemperature', async (data) => {
        const newData = new Temperature();
        newData.newTemperature = data.temperature;
        newData.createdBy = new Date().toLocaleString();
        newData.uuid = data.uuid;
        await newData.save(data, (err: any, result: any) => {
            if (err) {
                socket.emit('responseUpdateTemperature', JSON.stringify({
                    uuid: data.uuid,
                    status: 'Failure',
                    updatedOn: Date.now(),
                    type: 'Temperature'
                }));
                throw err;
            }
            socket.emit('responseUpdateTemperature', JSON.stringify({
                uuid: data.uuid,
                status: 'Success',
                updatedOn: Date.now(),
                type: 'Temperature'
            }));
        });
    });
});

function normalizePort(param: number | string): number | string | boolean {
    const portNumber: number = typeof param === 'string' ? parseInt(param, 10) : param;
    if (isNaN(portNumber)) return param;
    else if (portNumber >= 0) return portNumber;
    else return false;
}

function onServerError(error: NodeJS.ErrnoException): void {
    if (error.syscall !== 'listen') throw error;
    const bind = typeof port === 'string' ? 'Pipe ' + port : 'Port ' + port;
    switch (error.code) {
        case 'EACCES':
            winstonLogger.error(`${bind} requires elevated privileges`);
            process.exit(1);
            break;
        case 'EADDRINUSE':
            winstonLogger.error(`${bind} is already in use`);
            process.exit(1);
            break;
        default:
            throw error;
    }
}

function onServerListening() {
    const addr = server.address();
    winstonLogger.info('-----Express Server started');
}
