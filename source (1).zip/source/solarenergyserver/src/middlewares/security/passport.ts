import {authenticate, PassportStatic} from 'passport';
import {ExtractJwt, Strategy, StrategyOptions, VerifiedCallback} from 'passport-jwt';
import {MongoError} from 'mongodb';
import {UserRepository} from '../../repositories';
import {User} from '../../models';
import {SignUpResponseInterface} from '../../utils/interfaces';

export const authenticateUser = (passport: PassportStatic) => {
    const options: StrategyOptions = {
        jwtFromRequest: ExtractJwt.fromAuthHeaderWithScheme('jwt'),
        secretOrKey: process.env.JWT_SECRET || 'test_1',
    };
    const _userRepository = new UserRepository(User);

    passport.use(new Strategy(options, async (jwtPayload: IJwtPayload, done: VerifiedCallback) => {
        const result = await _userRepository.getUserById(jwtPayload.user._id);

        if (result instanceof MongoError) return done(result, false);
        if (!result) {
            return done(null, false);
        } else {
            return done(null, result, {issuedAt: jwtPayload.iat});
        }
    }));
};

interface IJwtPayload {
    user?: SignUpResponseInterface;
    iat?: Date;
}

