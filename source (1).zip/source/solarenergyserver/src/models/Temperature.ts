import {Document, Model, model, Schema} from "mongoose";

export const TemperatureSchema = new Schema({
    newTemperature: Number,
    createdBy: String,
    uuid: String,
}, {
    collection: 'temperature'
});

export interface TemperatureInterface extends Document {
    uuid: string;
    createdBy: string;
    newTemperature: number;
}

export type TemperatureModel = Model<TemperatureInterface>;
export const Temperature: TemperatureModel = model<TemperatureInterface>('Temperature', TemperatureSchema) as TemperatureModel;
