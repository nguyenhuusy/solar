import {Document, Model, model, Schema} from "mongoose";
import {EntityType} from '../utils/enum';

export const EntitySchema = new Schema({
    stationUuid: String,
    createdBy: String,
    value: Number,
    type: Number,
}, {
    collection: 'entities'
});

export interface EntityInterface extends Document {
    stationUuid: string;
    createdBy: string;
    value: number;
    type: EntityType;
}

export type EntityModel = Model<EntityInterface>;
export const Entity: EntityModel = model<EntityInterface>('Entity', EntitySchema) as EntityModel;
