export interface SignInResponseInterface {
    token: string;
}
