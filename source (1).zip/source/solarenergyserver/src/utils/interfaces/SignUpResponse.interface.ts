export interface SignUpResponseInterface {
    _id: string;
    username?: string;
    email?: string;
    password?: string;
}
