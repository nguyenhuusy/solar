export interface LocationDataInterface {
    uuid: string;
    lat: number;
    long: number;
}
