import {Voltage} from '../models';
import {VoltageRepository} from '../repositories/VoltageRepository';
import {OnEventSocket} from '../utils/enum';
import {EntityDataInterface} from '../utils/interfaces';
import {EmailController} from './EmailController';

export class VoltageController {
    private readonly _voltageRepository = new VoltageRepository(Voltage);

    async getVoltages(uuid: string, limit: number) {
        return await this._voltageRepository.getVoltage(+limit);
    }

    handleEvent(socket: any) {
        // socket.on(OnEventSocket.RequestUpdateVoltage, async (data: EntityDataInterface) => {
        //     if (data.voltage < 2) {
        //         const controller = new EmailController();
        //         controller.sendMail()
        //             .then(() => {
        //                 console.log('-----Warning voltage');
        //             })
        //             .catch(error => {
        //                 console.error(error);
        //             })
        //     }
        //
        //     const newData = new Voltage();
        //     newData.newVoltage = data.voltage;
        //     newData.createdBy = new Date().toLocaleString();
        //     newData.uuid = data.uuid;
        //     await newData.save({}, async (err: any, result: any) => {
        //         if (err) {
        //             socket.emit('responseUpdateVoltage', JSON.stringify({
        //                 uuid: data.uuid,
        //                 status: 'Failure',
        //                 updatedOn: Date.now(),
        //                 type: 'Voltage'
        //             }));
        //             throw err;
        //         }
        //         socket.emit('responseUpdateVoltage', JSON.stringify({
        //             uuid: data.uuid,
        //             status: 'Success',
        //             updatedOn: Date.now(),
        //             type: 'Voltage'
        //         }));
        //         const voltages = await this._voltageRepository.getVoltage(10);
        //         socket.emit('updateVoltage', voltages);
        //     });
        // });
    }

    // updateVoltage() {
    //     const newData = [];
    //     for (let i = 0; i < 11; i++) {
    //         newData.push({
    //             uuid: 'd0b96e26-c125-4003-a8b1-3921daf8fc07',
    //             newVoltage: this.generateRandomNumber(11.5, 12.5),
    //             createdBy: new Date().toLocaleString(),
    //         })
    //     }
    //     return newData;
    // }
    //
    // generateRandomNumber(min: number, max: number) {
    //     return (Math.random() * (max - min) + min).toFixed(2);
    // };
}
