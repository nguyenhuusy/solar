import * as nodemailer from 'nodemailer';
import config from 'config';

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: config.get('mail.username'),
        pass: config.get('mail.password'),
    },
});

export class EmailController {
    async sendMail() {
        const mailOptions = {
            to: "41204560@hcmut.edu.vn",
            from: config.get('mail.username').toString(),
            subject: "Contact Form",
            text: 'This is auto email to inform that it maybe have some problem with your system. Please check!',
        };

        transporter.sendMail(mailOptions, (err) => {
            if (err) {
                console.error(err);
            }
            console.log('Email is sent!');
        });
    }
}
