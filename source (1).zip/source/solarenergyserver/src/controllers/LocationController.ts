import {LocationRepository} from '../repositories';
import {Location, LocationInterface} from '../models';
import {LocationDataInterface} from '../utils/interfaces';
import {EmitEventSocket, OnEventSocket} from '../utils/enum';

export class LocationController {
    private readonly _locationRepository = new LocationRepository(Location);

    handleEvent(socket: any) {
        socket.on(OnEventSocket.RequestUpdateLocation, async (data: LocationDataInterface) => {
            try {
                await this.saveEntity(data);
                socket.emit(EmitEventSocket.ResponseUpdateLocation, LocationController.getResultFromSaveLocation({
                    isSuccess: true,
                    data
                }));
            } catch (e) {
                console.error(e);
                socket.emit(EmitEventSocket.ResponseUpdateLocation, LocationController.getResultFromSaveLocation({
                    isSuccess: false,
                    data
                }));
            }
        });
    }

    private async saveEntity(data: LocationDataInterface) {
        const fetchLocation = await this._locationRepository.getLocationByUuid(data.uuid);
        if (fetchLocation) {
            fetchLocation.latitude = data.lat;
            fetchLocation.longitude = data.long;
            return await this._locationRepository.updateLocation(fetchLocation._id, fetchLocation);
        }
        const newLocation = new Location();
        newLocation.uuid = data.uuid;
        newLocation.latitude = data.lat;
        newLocation.longitude = data.long;
        return await this._locationRepository.createLocation(newLocation);
    }

    private static getResultFromSaveLocation(result: { data: any, isSuccess: boolean }) {
        return {
            uuid: result.data.uuid,
            status: result.isSuccess ? 'Success' : 'Fail',
            updatedOn: Date.now(),
            type: 'GPS',
            latitude: result.data.latitude,
            longitude: result.data.longitude,
        }
    }

    async getLocations(): Promise<LocationInterface[]> {
        return await this._locationRepository.getLocations();
    }
}
