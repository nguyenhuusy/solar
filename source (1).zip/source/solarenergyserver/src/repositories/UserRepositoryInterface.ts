import {UserInterface} from '../models';

export interface UserRepositoryInterface {
    createUser(newUser: UserInterface): void;

    getUserByUsername(username: string): void;

    getUserByEmailOrUsername(email: string, username: string): Promise<UserInterface>;

    getUserById(id: string): void;

    updateUser(id: string, updatedUser: UserInterface): void;
}
