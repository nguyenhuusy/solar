import {EntityInterface} from '../models';
import {EntityType} from '../utils/enum';

export interface EntityRepositoryInterface {
    createEntity(newEntity: EntityInterface): void;

    getEntities(type: EntityType, limit: number): void;
}
