import {EntityInterface, EntityModel} from '../models';
import {EntityRepositoryInterface} from './EntityRepositoryInterface';

export class EntityRepository implements EntityRepositoryInterface {
    private _entityModel: EntityModel;

    constructor(entityModel: EntityModel) {
        this._entityModel = entityModel;
    }

    async createEntity(newEntity: EntityInterface): Promise<EntityInterface> {
        return this._entityModel.create(newEntity);
    }

    async getEntities(query: any): Promise<EntityInterface[]> {
        if (query.limit) {
            const _limit = query.limit;
            const {limit, ...rest} = query;
            return await this._entityModel.find({
                stationUuid: rest.stationUuid,
                type: rest.type
            }).sort({$natural: -1}).limit(+_limit).exec();
        }
        return await this._entityModel.find(query).exec();
    }
}
