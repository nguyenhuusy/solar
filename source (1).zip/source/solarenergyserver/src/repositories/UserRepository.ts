import {UserInterface, UserModel} from '../models';
import {UserRepositoryInterface} from './UserRepositoryInterface';

export class UserRepository implements UserRepositoryInterface {
    private _userModel: UserModel;

    constructor(userModel: UserModel) {
        this._userModel = userModel;
    }

    async createUser(newUser: UserInterface): Promise<UserInterface> {
        return await this._userModel.create(newUser);
    }

    async getUserByUsername(username: string): Promise<UserInterface> {
        const query = {username};
        return await this._userModel.findOne(query);
    }

    async getUserByEmailOrUsername(email: string, username: string): Promise<UserInterface> {
        const query = {$or: [{email}, {username}]};
        return await this._userModel.findOne(query);
    }

    async getUserById(id: string): Promise<UserInterface> {
        return await this._userModel.findById(id);
    }

    async updateUser(id: string, updatedUser: UserInterface): Promise<UserInterface> {
        return await this._userModel.findByIdAndUpdate(id, updatedUser, {new: true});
    }
}
