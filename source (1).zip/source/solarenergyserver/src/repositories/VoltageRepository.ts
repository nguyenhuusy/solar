import {VoltageModel} from '../models';
import {VoltageRepositoryInterface} from './VoltageRepositoryInterface';

export class VoltageRepository implements VoltageRepositoryInterface {
    private _voltageModel: VoltageModel;

    constructor(voltageModel: VoltageModel) {
        this._voltageModel = voltageModel;
    }

    async getVoltage(limit: number) {
        return await this._voltageModel.find().sort({createdBy: -1}).limit(+limit).exec();
    }
}
