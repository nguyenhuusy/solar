import {TemperatureModel} from '../models';
import {TemperatureRepositoryInterface} from './TemperatureRepositoryInterface';

export class TemperatureRepository implements TemperatureRepositoryInterface {
    private _temperatureModel: TemperatureModel;

    constructor(temperatureModel: TemperatureModel) {
        this._temperatureModel = temperatureModel;
    }

    async getTemperature(limit: number) {
        return await this._temperatureModel.find().sort({createdBy: -1}).limit(+limit).exec();
    }
}
