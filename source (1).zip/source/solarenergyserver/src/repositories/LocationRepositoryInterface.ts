import {LocationInterface} from '../models';

export interface LocationRepositoryInterface {
    createLocation(newLocation: LocationInterface): void;

    getLocationById(id: string): void;

    getLocationByUuid(uuid: string): void;

    updateLocation(id: string, updatedLocation: LocationInterface): void;
}
