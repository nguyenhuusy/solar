const data1 = {
    year: 2019,
    month: 1,
    data: [
        {
            "date": "01-01-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "02-01-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "03-01-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "04-01-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "05-01-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "06-01-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "07-01-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "08-01-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "09-01-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "10-01-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "11-01-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "12-01-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "13-01-2019",
            "voltage": 12,
            "temperature": 32
        },
        {
            "date": "14-01-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "15-01-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "16-01-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "17-01-2019",
            "voltage": 10,
            "temperature": 28
        },
        {
            "date": "18-01-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "19-01-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "20-01-2019",
            "voltage": 12,
            "temperature": 32
        },
        {
            "date": "21-01-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "22-01-2019",
            "voltage": 11,
            "temperature": 30
        },
        {
            "date": "23-01-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "24-01-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "25-01-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "26-01-2019",
            "voltage": 12,
            "temperature": 28
        },
        {
            "date": "27-01-2019",
            "voltage": 11,
            "temperature": 30
        },
        {
            "date": "28-01-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "29-01-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "30-01-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "31-01-2019",
            "voltage": 13,
            "temperature": 28
        }
    ]
};

export default data1;
