const data10 = {
    year: 2019,
    month: 5,
    data: [
        {
            "date": "01-05-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "02-05-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "03-05-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "04-05-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "05-05-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "06-05-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "07-05-2019",
            "voltage": 10,
            "temperature": 31
        },
        {
            "date": "08-05-2019",
            "voltage": 13,
            "temperature": 28
        },
        {
            "date": "09-05-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "10-05-2019",
            "voltage": 10,
            "temperature": 30
        },
        {
            "date": "11-05-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "12-05-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "13-05-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "14-05-2019",
            "voltage": 13,
            "temperature": 28
        },
        {
            "date": "15-05-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "16-05-2019",
            "voltage": 10,
            "temperature": 32
        },
        {
            "date": "17-05-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "18-05-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "19-05-2019",
            "voltage": 10,
            "temperature": 32
        },
        {
            "date": "20-05-2019",
            "voltage": 13,
            "temperature": 28
        },
        {
            "date": "21-05-2019",
            "voltage": 12,
            "temperature": 32
        },
        {
            "date": "22-05-2019",
            "voltage": 10,
            "temperature": 32
        },
        {
            "date": "23-05-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "24-05-2019",
            "voltage": 10,
            "temperature": 32
        },
        {
            "date": "25-05-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "26-05-2019",
            "voltage": 12,
            "temperature": 30
        },
        {
            "date": "27-05-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "28-05-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "29-05-2019",
            "voltage": 13,
            "temperature": 29
        },
        {
            "date": "30-05-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "31-05-2019",
            "voltage": 11,
            "temperature": 28
        }
    ]
};

export default data10;
