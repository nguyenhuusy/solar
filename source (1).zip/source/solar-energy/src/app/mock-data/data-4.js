const data4 = {
    year: 2019,
    month: 4,
    data: [
        {
            "date": "01-04-2019",
            "voltage": 12,
            "temperature": 32
        },
        {
            "date": "02-04-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "03-04-2019",
            "voltage": 12,
            "temperature": 32
        },
        {
            "date": "04-04-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "05-04-2019",
            "voltage": 12,
            "temperature": 28
        },
        {
            "date": "06-04-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "07-04-2019",
            "voltage": 13,
            "temperature": 30
        },
        {
            "date": "08-04-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "09-04-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "10-04-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "11-04-2019",
            "voltage": 12,
            "temperature": 30
        },
        {
            "date": "12-04-2019",
            "voltage": 12,
            "temperature": 32
        },
        {
            "date": "13-04-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "14-04-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "15-04-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "16-04-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "17-04-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "18-04-2019",
            "voltage": 11,
            "temperature": 31
        },
        {
            "date": "19-04-2019",
            "voltage": 12,
            "temperature": 29
        },
        {
            "date": "20-04-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "21-04-2019",
            "voltage": 11,
            "temperature": 32
        },
        {
            "date": "22-04-2019",
            "voltage": 13,
            "temperature": 28
        },
        {
            "date": "23-04-2019",
            "voltage": 11,
            "temperature": 29
        },
        {
            "date": "24-04-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "25-04-2019",
            "voltage": 10,
            "temperature": 29
        },
        {
            "date": "26-04-2019",
            "voltage": 13,
            "temperature": 32
        },
        {
            "date": "27-04-2019",
            "voltage": 13,
            "temperature": 31
        },
        {
            "date": "28-04-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "29-04-2019",
            "voltage": 11,
            "temperature": 28
        },
        {
            "date": "30-04-2019",
            "voltage": 11,
            "temperature": 30
        }
    ]
};

export default data4;
